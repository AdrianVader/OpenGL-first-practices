
/* Authors:
			Adri�n Rabad�n Jurado
			and
			Teresa Rodr�guez Ferreira
*/


#include "PV2D.h"



PV2D::PV2D(const GLdouble &x, const GLdouble &y){

	PV2D::_x = x;
	PV2D::_y = y;

}

PV2D::PV2D(void)
{
}

PV2D::~PV2D(void)
{
}
